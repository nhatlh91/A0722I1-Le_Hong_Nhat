package com.example.librarymgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryMgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
